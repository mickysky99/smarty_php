<?php
/* Smarty version 3.1.33, created on 2019-01-18 15:08:28
  from '/home/vionalco/izipal.com/content/themes/default/templates/__feeds_post.text.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c41ebecf26372_28635953',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '703f521d45227c5bae57083abf13747dd65a393d' => 
    array (
      0 => '/home/vionalco/izipal.com/content/themes/default/templates/__feeds_post.text.tpl',
      1 => 1547821169,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c41ebecf26372_28635953 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="post-replace">
    <div class="post-text js_readmore" dir="auto"><?php echo $_smarty_tpl->tpl_vars['post']->value['text'];?>
</div>
    <div class="post-text-translation x-hidden" dir="auto"></div>
    <div class="post-text-plain hidden"><?php echo $_smarty_tpl->tpl_vars['post']->value['text_plain'];?>
</div>
</div><?php }
}
