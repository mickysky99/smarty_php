<?php
/* Smarty version 3.1.33, created on 2019-01-18 15:06:38
  from '/home/vionalco/izipal.com/content/themes/default/templates/ajax.chat.master.head.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c41eb7ed31ce6_34121952',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ece55169c6727a367f4d46ccc84a709337a3f86d' => 
    array (
      0 => '/home/vionalco/izipal.com/content/themes/default/templates/ajax.chat.master.head.tpl',
      1 => 1547821126,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c41eb7ed31ce6_34121952 (Smarty_Internal_Template $_smarty_tpl) {
if ($_smarty_tpl->tpl_vars['offline']->value) {?>

    <div class="chat-head-title">
        <i class="fa fa-user-secret"></i>
        <?php echo __("Offline");?>

    </div>

<?php } else { ?>

    <div class="chat-head-title">
        <i class="fa fa-circle"></i>
        (<?php echo count($_smarty_tpl->tpl_vars['online_friends']->value);?>
)
    </div>

<?php }
}
}
